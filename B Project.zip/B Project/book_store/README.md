# BookStore E-Commerce Platform

A comprehensive e-commerce platform built with Django and Django REST Framework for selling books online.

## 🚀 Features

### User Authentication & Management
- **Sign Up**: User registration with email, password, and optional profile information
- **Login**: Secure authentication with JWT tokens
- **Logout**: Session management and secure logout
- **Password Reset**: Email-based password recovery
- **User Profiles**: Extended user information including phone numbers and addresses

### Product Management (CRUD)
- **Add Products**: Admin can add books with details (title, author, price, ISBN, category, cover image)
- **Update Products**: Edit existing book information
- **Delete Products**: Remove books from inventory
- **List/View Products**: Browse books with filtering by category, search, and price range
- **Stock Management**: Track inventory levels

### Shopping Cart (CRUD)
- **Add to Cart**: Add books to shopping cart with quantity selection
- **Update Quantities**: Modify item quantities in cart
- **Remove Items**: Delete specific items from cart
- **View Cart**: Display cart contents with total price calculation
- **Clear Cart**: Empty entire cart

### Order Management (CRUD)
- **Place Orders**: Convert cart contents to orders with shipping information
- **Order History**: Users can view their past orders
- **Order Tracking**: Track order status (pending, confirmed, shipped, delivered)
- **Admin Order Management**: Admins can view all orders and update statuses
- **Order Cancellation**: Cancel orders when needed

### Additional Features
- **Wishlist**: Save books for later purchase
- **Book Categories**: Fiction, Non-Fiction, Academic, Mystery, Romance, Science Fiction, Biography
- **Search & Filter**: Advanced search and filtering capabilities
- **Responsive Design**: Mobile-friendly Bootstrap interface
- **Admin Dashboard**: Comprehensive admin interface for managing all aspects
- **API Documentation**: Interactive Swagger documentation

## 🛠️ Tech Stack

- **Backend**: Django 5.2.6 + Django REST Framework
- **Frontend**: HTML5, CSS3, JavaScript, Bootstrap 5.3
- **Database**: SQLite (development) / PostgreSQL (production ready)
- **Authentication**: JWT (JSON Web Tokens)
- **API Documentation**: Swagger/OpenAPI (drf-yasg)
- **Image Handling**: Pillow for image processing

## 📦 Installation & Setup

### Quick Start (Windows)
1. Download or clone the project
2. Open Command Prompt in the project directory
3. Run the setup script:
   ```cmd
   setup_and_run.bat
   ```

### Quick Start (Linux/Mac)
1. Download or clone the project
2. Open Terminal in the project directory
3. Make the script executable and run:
   ```bash
   chmod +x setup_and_run.sh
   ./setup_and_run.sh
   ```

### Manual Setup

#### Prerequisites
- Python 3.8 or higher
- pip (Python package installer)

#### Step-by-Step Installation

1. **Install Dependencies**
   ```bash
   pip install -r requirements.txt
   ```

2. **Database Setup**
   ```bash
   python manage.py makemigrations
   python manage.py migrate
   ```

3. **Initialize Sample Data**
   ```bash
   python initialize_data.py
   ```

4. **Run Development Server**
   ```bash
   python manage.py runserver
   ```

5. **Access the Application**
   - Website: http://127.0.0.1:8000/
   - Admin Panel: http://127.0.0.1:8000/admin/
   - API Documentation: http://127.0.0.1:8000/swagger/

## 👤 Default Credentials

### Admin User
- **Username**: admin
- **Password**: admin123
- **Email**: admin@bookstore.com

### Test Users
- **Username**: johndoe / **Password**: testpass123
- **Username**: janedoe / **Password**: testpass123

## 🔗 API Endpoints

### Authentication
- `POST /api/auth/signup/` - User registration
- `POST /api/auth/login/` - User login (returns JWT tokens)
- `POST /api/auth/token/refresh/` - Refresh JWT token
- `POST /api/auth/password-reset/` - Request password reset
- `GET /api/auth/profile/` - Get user profile

### Books
- `GET /api/books/` - List all books (with pagination, search, filters)
- `POST /api/books/` - Create new book (Admin only)
- `GET /api/books/{id}/` - Get specific book details
- `PUT /api/books/{id}/` - Update book (Admin only)
- `DELETE /api/books/{id}/` - Delete book (Admin only)

### Cart Management
- `GET /api/cart/current/` - Get user's current cart
- `POST /api/cart/add_item/` - Add item to cart
- `PATCH /api/cart/update_item/` - Update cart item quantity
- `DELETE /api/cart/remove_item/` - Remove item from cart
- `DELETE /api/cart/clear/` - Clear entire cart

### Orders
- `GET /api/orders/` - List user orders (All orders for admin)
- `POST /api/orders/create_from_cart/` - Create order from cart
- `GET /api/orders/{id}/` - Get order details
- `PATCH /api/orders/{id}/update_status/` - Update order status (Admin only)

### Wishlist
- `GET /api/wishlist/current/` - Get user's wishlist
- `POST /api/wishlist/add_book/` - Add book to wishlist
- `DELETE /api/wishlist/remove_book/` - Remove book from wishlist

## 🎨 Frontend Features

### Responsive Design
- Mobile-first Bootstrap 5.3 design
- Responsive navigation with dropdown menus
- Card-based book display layout
- Mobile-optimized forms and buttons

### User Interface
- **Homepage**: Hero section, featured books, category browsing
- **Book Catalog**: Grid layout with search and filtering
- **Shopping Cart**: Interactive cart management
- **User Dashboard**: Profile, order history, wishlist
- **Admin Panel**: Comprehensive management interface

### Interactive Elements
- Real-time cart updates
- AJAX-powered book loading
- Form validation
- Loading indicators
- Error handling and user feedback

## 🔧 Configuration

### Database Configuration
For production, uncomment PostgreSQL settings in `backend/settings.py`:
```python
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': os.environ.get('DB_NAME', 'bookstore'),
        'USER': os.environ.get('DB_USER', 'postgres'),
        'PASSWORD': os.environ.get('DB_PASSWORD', 'password'),
        'HOST': os.environ.get('DB_HOST', 'localhost'),
        'PORT': os.environ.get('DB_PORT', '5432'),
    }
}
```

### Email Configuration
For production email functionality, update settings in `backend/settings.py`:
```python
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_PORT = 587
EMAIL_USE_TLS = True
EMAIL_HOST_USER = 'your-email@gmail.com'
EMAIL_HOST_PASSWORD = 'your-app-password'
```

## 📊 Admin Features

### Book Management
- Add, edit, delete books
- Manage categories and inventory
- Upload cover images
- Bulk operations

### Order Management
- View all orders
- Update order statuses
- Track shipping information
- Generate reports

### User Management
- View registered users
- Manage user profiles
- Reset passwords
- Monitor activity

## 🔒 Security Features

- JWT token authentication
- CSRF protection
- Password validation
- Secure admin interface
- SQL injection prevention
- XSS protection

## 📱 Mobile Responsiveness

The platform is fully responsive and works seamlessly on:
- Desktop computers
- Tablets
- Mobile phones
- Various screen sizes

## 🚀 Deployment Options

### Development
The project runs locally using Django's development server.

### Production
For production deployment:
1. Set `DEBUG = False` in settings
2. Configure PostgreSQL database
3. Set up proper web server (nginx + gunicorn)
4. Configure SSL certificates
5. Set up static file serving

### Creating Executable
To create a standalone executable:
1. Install PyInstaller: `pip install pyinstaller`
2. Create executable: `pyinstaller --onefile manage.py`
3. Package with all dependencies and static files

## 📚 Sample Data

The application comes with pre-loaded sample data:
- 15 books across different categories
- Sample user accounts for testing
- Admin account for management

## 🔍 API Documentation

Interactive API documentation is available at:
- Swagger UI: http://127.0.0.1:8000/swagger/
- ReDoc: http://127.0.0.1:8000/redoc/

## 🤝 Support

For issues or questions:
1. Check the API documentation
2. Review the admin panel
3. Test with provided sample accounts
4. Check console logs for debugging

## 📄 License

This project is open source and available under the MIT License.

## 🎯 Future Enhancements

Potential improvements:
- Payment gateway integration
- Email notifications
- Advanced search with Elasticsearch
- Product reviews and ratings
- Recommendation engine
- Multi-language support
- Mobile app development

---

**Happy coding! 📚🛒**