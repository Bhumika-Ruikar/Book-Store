# book_store/book_store/urls.py
from django.contrib import admin
from django.urls import path, include
from api.views import index

urlpatterns = [
    path('', index, name='index'),
    path('admin/', admin.site.urls),
    path('api/', include('api.urls')),

    # Add Django's built-in auth URLs for login, logout, etc.
    path('accounts/', include('django.contrib.auth.urls')),
]