#!/bin/bash

echo "===================================="
echo "   BookStore Setup and Deployment"
echo "===================================="

echo
echo "1. Installing Python packages..."
pip install -r requirements.txt
if [ $? -ne 0 ]; then
    echo "ERROR: Failed to install packages. Please check your Python/pip installation."
    exit 1
fi

echo
echo "2. Making migrations..."
python manage.py makemigrations
if [ $? -ne 0 ]; then
    echo "ERROR: Failed to create migrations."
    exit 1
fi

echo
echo "3. Running migrations..."
python manage.py migrate
if [ $? -ne 0 ]; then
    echo "ERROR: Failed to run migrations."
    exit 1
fi

echo
echo "4. Creating media directories..."
mkdir -p media/book_covers
mkdir -p staticfiles

echo
echo "5. Collecting static files..."
python manage.py collectstatic --noinput
if [ $? -ne 0 ]; then
    echo "WARNING: Failed to collect static files, continuing..."
fi

echo
echo "6. Initializing database with sample data..."
python initialize_data.py
if [ $? -ne 0 ]; then
    echo "ERROR: Failed to initialize sample data."
    exit 1
fi

echo
echo "===================================="
echo "     Setup completed successfully!"
echo "===================================="
echo
echo "Admin credentials:"
echo "Username: admin"
echo "Password: admin123"
echo
echo "Test user credentials:"
echo "Username: johndoe / janedoe"
echo "Password: testpass123"
echo
echo "Starting development server..."
echo "Open http://127.0.0.1:8000/ in your browser"
echo

python manage.py runserver