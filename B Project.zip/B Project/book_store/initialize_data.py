import os
import django
import sys

# Add the project root to the Python path
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, project_root)

# Set up Django settings
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'backend.settings')
django.setup()

from django.contrib.auth.models import User
from api.models import Book, UserProfile, Cart, Wishlist

def create_sample_books():
    """Create sample books for the store"""
    books_data = [
        {
            'title': 'The Great Gatsby',
            'author': 'F. Scott Fitzgerald',
            'description': 'A classic American novel about the Jazz Age and the American Dream.',
            'price': 12.99,
            'isbn': '9780743273565',
            'category': 'fiction',
            'stock': 50,
            'cover_image_url': 'https://images-na.ssl-images-amazon.com/images/I/81af+MCATTL.jpg'
        },
        {
            'title': 'To Kill a Mockingbird',
            'author': 'Harper Lee',
            'description': 'A gripping tale of racial injustice and childhood innocence.',
            'price': 14.99,
            'isbn': '9780061120084',
            'category': 'fiction',
            'stock': 30,
            'cover_image_url': 'https://images-na.ssl-images-amazon.com/images/I/71FxgtFKcQL.jpg'
        },
        {
            'title': '1984',
            'author': 'George Orwell',
            'description': 'A dystopian masterpiece about totalitarian control.',
            'price': 13.99,
            'isbn': '9780451524935',
            'category': 'fiction',
            'stock': 25,
            'cover_image_url': 'https://images-na.ssl-images-amazon.com/images/I/71rpa1-kyvL.jpg'
        },
        {
            'title': 'The Catcher in the Rye',
            'author': 'J.D. Salinger',
            'description': 'A coming-of-age story that has captivated readers for generations.',
            'price': 11.99,
            'isbn': '9780316769174',
            'category': 'fiction',
            'stock': 40,
            'cover_image_url': 'https://images-na.ssl-images-amazon.com/images/I/53E4YvxSkuL.jpg'
        },
        {
            'title': 'Pride and Prejudice',
            'author': 'Jane Austen',
            'description': 'A romantic novel about manners, upbringing, morality, and marriage.',
            'price': 10.99,
            'isbn': '9780141439518',
            'category': 'romance',
            'stock': 35,
            'cover_image_url': 'https://images-na.ssl-images-amazon.com/images/I/71Q1tPupKjL.jpg'
        },
        {
            'title': 'The Hobbit',
            'author': 'J.R.R. Tolkien',
            'description': 'A fantasy adventure about Bilbo Baggins and his journey.',
            'price': 15.99,
            'isbn': '9780547928227',
            'category': 'science-fiction',
            'stock': 45,
            'cover_image_url': 'https://images-na.ssl-images-amazon.com/images/I/712cDO7d73L.jpg'
        },
        {
            'title': 'Sapiens: A Brief History of Humankind',
            'author': 'Yuval Noah Harari',
            'description': 'An exploration of how Homo sapiens came to dominate Earth.',
            'price': 18.99,
            'isbn': '9780062316097',
            'category': 'non-fiction',
            'stock': 20,
            'cover_image_url': 'https://images-na.ssl-images-amazon.com/images/I/713jIoMO3UL.jpg'
        },
        {
            'title': 'The Lean Startup',
            'author': 'Eric Ries',
            'description': 'How constant innovation creates radically successful businesses.',
            'price': 16.99,
            'isbn': '9780307887894',
            'category': 'non-fiction',
            'stock': 15,
            'cover_image_url': 'https://images-na.ssl-images-amazon.com/images/I/81-QB7nDh4L.jpg'
        },
        {
            'title': 'Introduction to Algorithms',
            'author': 'Thomas H. Cormen',
            'description': 'A comprehensive textbook on algorithms and data structures.',
            'price': 89.99,
            'isbn': '9780262033848',
            'category': 'academic',
            'stock': 10,
            'cover_image_url': 'https://images-na.ssl-images-amazon.com/images/I/41T0iBxY8FL.jpg'
        },
        {
            'title': 'Clean Code',
            'author': 'Robert C. Martin',
            'description': 'A handbook of agile software craftsmanship.',
            'price': 42.99,
            'isbn': '9780132350884',
            'category': 'academic',
            'stock': 12,
            'cover_image_url': 'https://images-na.ssl-images-amazon.com/images/I/41xShlnTZTL.jpg'
        },
        {
            'title': 'The Da Vinci Code',
            'author': 'Dan Brown',
            'description': 'A mystery thriller involving art, history, and conspiracy.',
            'price': 13.99,
            'isbn': '9780307474278',
            'category': 'mystery',
            'stock': 25,
            'cover_image_url': 'https://images-na.ssl-images-amazon.com/images/I/815WORuYMML.jpg'
        },
        {
            'title': 'Gone Girl',
            'author': 'Gillian Flynn',
            'description': 'A psychological thriller about a marriage gone terribly wrong.',
            'price': 14.99,
            'isbn': '9780307588371',
            'category': 'mystery',
            'stock': 20,
            'cover_image_url': 'https://images-na.ssl-images-amazon.com/images/I/71E4wdH66bL.jpg'
        },
        {
            'title': 'Steve Jobs',
            'author': 'Walter Isaacson',
            'description': 'The exclusive biography of Apple co-founder Steve Jobs.',
            'price': 17.99,
            'isbn': '9781451648539',
            'category': 'biography',
            'stock': 18,
            'cover_image_url': 'https://images-na.ssl-images-amazon.com/images/I/81VStYnDGrL.jpg'
        },
        {
            'title': 'Becoming',
            'author': 'Michelle Obama',
            'description': 'The memoir of former First Lady Michelle Obama.',
            'price': 19.99,
            'isbn': '9781524763138',
            'category': 'biography',
            'stock': 22,
            'cover_image_url': 'https://images-na.ssl-images-amazon.com/images/I/81h2gWPTYJL.jpg'
        },
        {
            'title': 'The Notebook',
            'author': 'Nicholas Sparks',
            'description': 'A romantic story of enduring love and devotion.',
            'price': 12.99,
            'isbn': '9780446605236',
            'category': 'romance',
            'stock': 28,
            'cover_image_url': 'https://images-na.ssl-images-amazon.com/images/I/81nNRHOE4XL.jpg'
        }
    ]
    
    created_count = 0
    for book_data in books_data:
        book, created = Book.objects.get_or_create(
            isbn=book_data['isbn'],
            defaults=book_data
        )
        if created:
            created_count += 1
            print(f"Created book: {book.title}")
        else:
            print(f"Book already exists: {book.title}")
    
    print(f"\nTotal books created: {created_count}")
    print(f"Total books in database: {Book.objects.count()}")

def create_admin_user():
    """Create admin user if it doesn't exist"""
    if not User.objects.filter(username='admin').exists():
        admin = User.objects.create_superuser(
            username='admin',
            email='admin@bookstore.com',
            password='admin123',
            first_name='Admin',
            last_name='User'
        )
        # Create profile, cart, and wishlist for admin
        UserProfile.objects.create(user=admin, phone_number='+1234567890')
        Cart.objects.create(user=admin)
        Wishlist.objects.create(user=admin)
        print("Admin user created: username='admin', password='admin123'")
    else:
        print("Admin user already exists")

def create_sample_users():
    """Create sample users for testing"""
    users_data = [
        {
            'username': 'johndoe',
            'email': 'john@example.com',
            'password': 'testpass123',
            'first_name': 'John',
            'last_name': 'Doe',
            'phone': '+1234567891'
        },
        {
            'username': 'janedoe',
            'email': 'jane@example.com', 
            'password': 'testpass123',
            'first_name': 'Jane',
            'last_name': 'Doe',
            'phone': '+1234567892'
        }
    ]
    
    created_count = 0
    for user_data in users_data:
        if not User.objects.filter(username=user_data['username']).exists():
            user = User.objects.create_user(
                username=user_data['username'],
                email=user_data['email'],
                password=user_data['password'],
                first_name=user_data['first_name'],
                last_name=user_data['last_name']
            )
            UserProfile.objects.create(user=user, phone_number=user_data['phone'])
            Cart.objects.create(user=user)
            Wishlist.objects.create(user=user)
            created_count += 1
            print(f"Created user: {user.username}")
        else:
            print(f"User already exists: {user_data['username']}")
    
    print(f"\nTotal sample users created: {created_count}")

if __name__ == '__main__':
    print("Initializing BookStore database with sample data...\n")
    
    print("1. Creating admin user...")
    create_admin_user()
    
    print("\n2. Creating sample users...")
    create_sample_users()
    
    print("\n3. Creating sample books...")
    create_sample_books()
    
    print("\nDatabase initialization completed!")
    print("\nYou can now:")
    print("1. Access admin panel at http://127.0.0.1:8000/admin/ (admin/admin123)")
    print("2. View API documentation at http://127.0.0.1:8000/swagger/")
    print("3. Test the website at http://127.0.0.1:8000/")